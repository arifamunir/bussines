<?php
if (isset($_POST['add_user'])) {
    $fullname = $_POST['fname'];
    $phone = $_POST['uphone'];
    $email = $_POST['uemail'];
    $pass = $_POST['upass'];
    $username = $_POST['uname'];
    $city = $_POST['ucity'];
    $query = "insert into  users(username,fullname,pass,email,phone,city) values('$username','$fullname','$pass','$email','$phone','$city')";

    if (mysqli_query($conn, $query)) {
        header('location: login.php');
    } else {
        echo "ERROR";
    }
}

?>
<?php include 'includes/header.php'; ?>


<div class="container-fluid mt-5">
    <center>
        <h2 class="mb-5">Registr As Employee</h2>
    </center>
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <form method="POST" enctype="multipart/form-data">
                <table class="table table-borderless">
                    <tr>
                        <td><b>Enter FullName</b></td>
                        <td><input type="text" class="form-control" name="fname" placeholder="Enter User FullName" required /></td>
                    </tr>
                    <tr>
                        <td><b>Enter Email Adress</b></td>
                        <td><input type="text" class="form-control" name="uemail" placeholder="Enter User Email Adress" required /></td>
                    </tr>
                    <tr>
                        <td><b>Enter Username</b></td>
                        <td><input type="text" class="form-control" name="uname" placeholder="Enter User Username " required /></td>
                    </tr>
                    <tr>
                        <td><b>Enter Password</b></td>
                        <td><input type="password" class="form-control" name="upass" placeholder="Enter Password For User" required /></td>
                    </tr>
                    <tr>
                        <td><b>Enter Phone</b></td>
                        <td><input type="text" class="form-control" name="uphone" placeholder="Enter User Phone Number" required /></td>
                    </tr>
                    <tr>
                        <td><b>Enter City</b></td>
                        <td><input type="text" class="form-control" name="ucity" placeholder="Enter User City" required /></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" name="add_user" class="btn btn-primary w-100" value="Register As Employee" /></td>
                    </tr>
                </table>
            </form>
        </div>
    </div>

</div>

<?php include 'includes/footer.php' ?>