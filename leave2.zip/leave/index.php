<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="public/css/bootstrap.css">
  <link rel="stylesheet" href="public/css/style.css">
  <title>Leave Managment System</title>
  <style>
    .padding {
      padding: 5% 25%;
      line-height: 30px;
    }
  </style>
</head>

<body>
  <div class="container-fluid bg-dark">
    <div class="row py-2">

      <div class="col-md-2 text-white py-2">
        Leave Managment System
      </div>
      <div class="col-md-10">
        <ul class="nav nav-fill">
          <li class="nav-item">
            <a class="nav-link text-white" href="index.php">Home</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link text-white" href="about.php">About Us</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link text-white" href="contact.php">Contact Us</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link text-white" href="register.php">Register</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link text-white" href="login.php">Login</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link text-white" href="logout.php">Logout</a>
          </li>

        </ul>
      </div>
    </div>

  </div>
  <div class="container-fluid padding">
    <h4>
      Leave <br> Managment <br> System
    </h4>
    <p class="w-75">
      This website is to streamline the process of requesting , approving and tracking of employees abscences. <br>
      Tracks and calculates users leave accurals and user leave balances and ensure that leave is taken within the allowd time frame.
    </p>
  </div>

  <?php include 'includes/footer.php' ?>