<?php include 'includes/header.php';
$result = mysqli_query($conn, "SELECT * FROM leave_types");

?>


<div class="container-fluid">
    <center>
        <h2 class="">Apply Leave</h2>
    </center>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-6">
            <form name="addemp" method="POST">

                <div class="card-body">
                    <h4 class="header-title">Employee Leave Form</h4>

                    <div class="form-group">
                        <label for="" class="col-form-label"> <b> Starting Date</b></label>
                        <input class="form-control" type="date" name="fromdate">
                    </div>

                    <div class="form-group">
                        <label for="" class="col-form-label"><b>End Date</b></label>
                        <input class="form-control" type="date" name="todate">
                    </div>

                    <div class="form-group">
                        <label class="col-form-label"><b>Your Leave Type</b></label>
                        <select name="" class="form-control">
                            <?php while ($row = mysqli_fetch_array($result)) {  ?>
                                <option value="<?php echo $row['typeId'] ?>"><?php echo $row['type'] ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="col-form-label"><b>Reason For Leave</b></label>
                        <textarea class="form-control" name="description" type="text" name="description" length="400" id="example-text-input" rows="5"></textarea>
                    </div>
                    <input type="submit" class="btn btn-info w-50 float-end mt-3" name="apply" value="Apply Leave">

                </div>
            </form>
        </div>
    </div>

</div>

<?php include 'includes/footer.php' ?>