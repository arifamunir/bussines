<script src="public/js/jquery.js"></script>
<script src="public/js/bootstrap.js"></script>

</body>

</html>