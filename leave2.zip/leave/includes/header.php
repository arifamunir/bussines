<?php
include 'connection.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/css/bootstrap.css">
    <link rel="stylesheet" href="public/css/style.css">
    <title>Leave Managment System</title>

</head>

<body>
    <div class="container-fluid bg-dark">
        <div class="row py-2">

            <div class="col-md-2 text-white py-2">
                Leave Managment System
            </div>
            <div class="col-md-10">
                <ul class="nav nav-fill">
                    <li class="nav-item">
                        <a class="nav-link text-white" href="index.php">Home</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link text-white" href="about.php">About Us</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link text-white" href="contact.php">Contact Us</a>
                    </li>
                    <?php if (empty($_SESSION['empId'])) { ?>
                        <li class="nav-item ">
                            <a class="nav-link text-white" href="register.php">Register</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link text-white" href="login.php">Login</a>
                        </li>
                    <?php } else { ?>
                        <li class="nav-item ">
                            <a class="nav-link text-white" href="apply-leave.php">Apply Leave</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link text-white" href="#">Leave Status</a>
                        </li>
                        <li class="nav-item ">
                            <a class="nav-link text-white" href="logout.php">Logout</a>
                        </li>
                    <?php } ?>
                </ul>
            </div>
        </div>

    </div>