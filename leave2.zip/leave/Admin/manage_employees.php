<?php
include 'db.php';
session_start();
$query = mysqli_query($conn, "SELECT * FROM users");
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM users WHERE userId='id'");
    header('location:manage_employees.php');
}

?>
<!DOCTYPE html>
<html>

<head>
    <title>Employees Leave Managment System</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
    </style>
</head>

<body>
    <nav class="container-fluid py-3 nav-back">
        <div class="row">
            <div class="col-md-8">
                <h4>ADMIN PANNEL &nbsp Leave Managment System</h4>
            </div>
            <div class="col-md-4">
                <a href="logout.php" class="btn btn-danger float-right">Logout</a>
            </div>
        </div>

    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 cust-bg px-0">
                <?php include 'nav.php' ?>
            </div>
            <div class="col-md-9 mx-4" style="background: #fff;">
                <span class="text-color">
                    <center> <b> MANAGE USERS </b></center>
                </span>
                <table class="table">
                    <tr>
                        <th>FULLNAME</th>
                        <th>USERNAME</th>
                        <th>EMAIL</th>
                        <th>PHONE</th>
                        <th>CITY</th>
                        <th>EDIT</th>
                        <th>DELETE</th>
                    </tr>
                    <?php while ($result = mysqli_fetch_array($query)) { ?>
                        <tr>
                            <td><?php echo $result['fullname'] ?></td>
                            <td><?php echo $result['username'] ?></td>
                            <td><?php echo $result['email'] ?></td>
                            <td><?php echo $result['phone'] ?></td>
                            <td><?php echo $result['city'] ?></td>
                            <td><a href="#" class="btn btn-dark w-100">EDIT</a></td>
                            <td><a href="?delete=<?php echo $result['userId'] ?>" class="btn btn-danger w-100">DELETE</a></td>
                        </tr>
                    <?php } ?>
                </table>
            </div>
        </div>

    </div>
    <?php include 'footer.php'; ?>
</body>

</html>