<?php
include 'db.php';
if (isset($_POST['add_type'])) {

  $type = $_POST['ltype'];
  $query = "insert into leave_types(type) values('$type')";
  mysqli_query($conn, $query);
  header('location:manange_leave_types.php');
}




?>
<!DOCTYPE html>
<html>

<head>
  <title>Employees Leave Managment System</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
  </style>
</head>

<body>
  <nav class="container-fluid py-3 nav-back">
    <div class="row">
      <div class="col-md-8">
        <h4>ADMIN PANNEL &nbsp Leave Managment System</h4>
      </div>
      <div class="col-md-4">
        <a href="logout.php" class="btn btn-danger float-right">Logout</a>
      </div>
    </div>

  </nav>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-2 cust-bg px-0">
        <?php include 'nav.php' ?>
      </div>
      <div class="col-md-8 mx-4 mt-4" style="background: #fff;">
        <form method="POST" enctype="multipart/form-data">

          <table class="table">
            <tr>
              <td colspan="2" class="text-color">
                <center>
                  <h5><b> ADD LEAVE TYPE</b></h5>
                </center>
              </td>
            </tr>
            <tr>
              <td>LEAVE TYPE</td>
              <td><input type="text" class="form-control" name="ltype" placeholder="Enter Leave Types" required></td>
            </tr>
            <tr>
              <td></td>
              <td colspan=""><input type="submit" name="add_type" class="btn w-100 cust-btn" value="ADD LEAVE TYPE" /></td>
            </tr>

          </table>
        </form>
      </div>
    </div>

  </div>
  <?php include 'footer.php'; ?>
</body>

</html>