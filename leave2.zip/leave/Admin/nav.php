 <ul class="nav nav-pills flex-column mb-auto">
   <li class="nav-item py-2">
     <a href="add_leave_types.php" class="nav-link" style="color: white;">
       ADD LEAVE TYPE
     </a>
   </li>
   <li class="nav-item py-2">
     <a href="manange_leave_types.php" class="nav-link " style="color: white;">
       MANAGE TYPES
     </a>
   </li>
   <li class="nav-item py-2">
     <a href="addemployees.php" class="nav-link" style="color: white;">
       ADD EMPLOYEE
     </a>
   </li>
   <li class="nav-item py-2">
     <a href="manage_employees.php" class="nav-link" style="color: white;">
       MANAGE EMPLOYEES
     </a>
   </li>

   <li class="nav-item py-2">
     <a href="#" class="nav-link" style="color: white;">
       VIEW LEAVES
     </a>
   </li>

   <li class="nav-item py-2">
     <a href="logout.php" class="nav-link" style="color: white;">
       LOGOUT
     </a>
   </li>

 </ul>