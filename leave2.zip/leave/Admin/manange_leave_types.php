<?php
include 'db.php';
session_start();

$query = "select * from leave_types";
$result = mysqli_query($conn, $query);
//script for delete inventory item 
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    mysqli_query($conn, "delete from leave_types where typeId='$id'");
    header('location:manange_leave_types.php');
}

?>
<!DOCTYPE html>
<html>

<head>
    <title>Employees Leave Managment System</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
    </style>
</head>

<body>
    <nav class="container-fluid py-3 nav-back">
        <div class="row">
            <div class="col-md-8">
                <h4>ADMIN PANNEL &nbsp Leave Managment System</h4>
            </div>
            <div class="col-md-4">
                <a href="logout.php" class="btn btn-danger float-right">Logout</a>
            </div>
        </div>

    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 cust-bg px-0">
                <?php include 'nav.php' ?>
            </div>
            <div class="col-md-8 mx-4 mt-4" style="background: #fff;">
                <form method="POST" enctype="multipart/form-data">
                    <center>
                        <h5 class="text-color"><b> MANAGE LEAVE TYPES</b></h5>
                    </center>
                    <table class="table">

                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Leave Type</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1;
                            while ($row = mysqli_fetch_array($result)) {
                            ?>
                                <tr>
                                    <td><?php echo $i++; ?></td>
                                    <td><?php echo $row['type']; ?></td>
                                    <td> <a href="#" class="btn btn-block btn-warning">EDIT</a></td>
                                    <td> <a href="?id=<?php echo $row['typeId']; ?>" class="btn btn-block btn-danger">DELETE</a></td>

                                </tr>
                            <?php

                            } ?>

                        </tbody>
                    </table>
                </form>
            </div>
        </div>

    </div>
    <?php include 'footer.php'; ?>
</body>

</html>