<nav class=" nav-back" style="position: absolute; bottom: 0px; width: 100%;">
    <center>
        <p class="py-3">All rights reserved to Faiza Student of Quaid e Azam Univerity</p>
    </center>
</nav>