<?php
include 'includes/header.php';
if (isset($_POST['login_user'])) {
    $username = $_POST['uname'];
    $password = $_POST['upass'];
    $query = "SELECT * FROM users WHERE username='$username' AND pass='$password'";
    $result = mysqli_query($conn, $query);
    $count = mysqli_num_rows($result);
    if ($count > 0) {
        $row = mysqli_fetch_array($result);
        $_SESSION['empId'] = $row['userId'];
        header('location: apply-leave.php');
    } else {
        echo "<script>alert('Invalid Username Or Password');</script>";
    }
}
?>

<div class="container mt-5">
    <center>
        <h2 class="mb-5">Login</h2>
    </center>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <form method="POST">
                <table class="table table-borderless">
                    <tr>
                        <td><b>Enter Username</b></td>
                        <td><input type="text" class="form-control" name="uname" placeholder="Enter User Username " required />
                        </td>
                    </tr>
                    <tr>
                        <td><b>Enter Password</b></td>
                        <td><input type="password" class="form-control" name="upass" placeholder="Enter Password For User" required />
                        </td>
                    </tr>

                    <tr>
                        <td></td>
                        <td><input type="submit" name="login_user" class="btn btn-success w-100" value="Login" />
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>

</div>

<?php include 'includes/footer.php' ?>