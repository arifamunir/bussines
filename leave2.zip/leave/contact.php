<?php
include 'includes/header.php';
if (isset($_POST['contact_us'])) {
    $fullname = $_POST['fname'];
    $message = $_POST['message'];
    $email = $_POST['email'];
    $query = "INSERT INTO contactus(fullname,message,email) VALUES('$fullname' , '$message' , '$email')";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Message Sent To Admin Of Website')</script>";
    }
}
?>
<div class="container-fluid px-0">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <center>
                <h4>CONTACT US</h4>
            </center>
            <form method="POST" enctype="multipart/form-data">
                <table class="table table-borderless">
                    <tr>
                        <td><b>Enter FullName</b></td>
                        <td><input type="text" class="form-control" name="fname" placeholder="Enter User FullName" required /></td>
                    </tr>
                    <tr>
                        <td><b>Enter Email Adress</b></td>
                        <td><input type="text" class="form-control" name="email" placeholder="Enter User Email Adress" required /></td>
                    </tr>
                    <tr>
                        <td><b>Enter Your Message</b></td>
                        <td>
                            <textarea name="message" class="form-control" rows="4"></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td><input type="submit" name="contact_us" class="btn btn-info w-100" value="CONTACT US" /></td>
                    </tr>
                </table>
            </form>

        </div>
    </div>
</div>
<?php include 'includes/footer.php' ?>